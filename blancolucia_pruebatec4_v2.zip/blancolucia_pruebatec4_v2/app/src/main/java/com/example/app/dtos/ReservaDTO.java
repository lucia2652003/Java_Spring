package com.example.app.dtos;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @NoArgsConstructor
public class ReservaDTO {

    /*Crea constructores, getters y setters, y asi hacemos limpieza del código*/

    private Long identificador;

    //Al emplear relaciones 1:N, debemos especificar a que DTO padre va dirigido @JsonManaged

    //Una reserva está en un único vuelo
    @JsonBackReference("vuelo-reserva")
    @JsonProperty("vueloId")
    private VueloDTO vuelo;
    /*
     * Referencia Vuelo JSON
     *  "vueloId" : {
     *    "idvuelo": 1
     * }
     * */


    //Una reserva tiene un único empleado
    @JsonBackReference("empleado-reserva")
    @JsonProperty("empleadoId")
    private EmpleadoDTO pasajero;
    /*
     * Hace referencia en JSON
     * "empleadoId":{
     *     "codempleado" : 1
     * }
     * */

    //Estos dos parámetros son para demostrar los IDS de las entidades asociadas

    @JsonProperty("codigo")
    private String vuelo_asociado;

    @JsonProperty("pasajero")
    private String empleado_asociado;
}
