package com.example.app.dtos;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HotelDTO {

    /*Crea constructores, getters y setters, y asi hacemos limpieza del código*/
    /*
     * Hace referencia en JSON
     * {
     *     "idhotel" : 1,
     *     "codhotel": ...,
     *     "nombre" : ...,
     *     "habitaciones": []
     * }
     * */
    @JsonProperty("idhotel")
    private Long idhotel;

    @JsonProperty("codhotel")
    private String codigo;

    @JsonProperty("nombre")
    private String nombre;

    @JsonProperty("lugar")
    private String lugar;

    //Relacion 1:N
    @JsonManagedReference("hotel-habitacion")
    @JsonProperty("habitaciones")
    private List<HabitacionDTO> habitaciones;

}
