package com.example.app.dtos;

import com.example.app.entities.Vuelo;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor
public class VueloDTO {

    /*Crea constructores, getters y setters, y asi hacemos limpieza del código*/

    /*
    * Referencia Vuelo JSON
    * {
    *    "idvuelo": 1,
    *    "numvuelo": ...,
    *    "origen": ...,
    *    "destino": ...,
    *    "asiento": ...,
    *    "precio": ...,
    *    "fecha_ida": ...,
    *    "fecha_vuelta": ...,
    *    "pasajeros": []
    * }
    * */

    @JsonProperty("idvuelo")
    private Long idvuelo;

    @JsonProperty("numvuelo")
    private String numero;

    private String origen;

    private String destino;

    private Vuelo.TipoAsiento asiento;

    private Double precio;

    @JsonProperty("fecha_ida")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fechaIda;

    //Establecer nombre en JSON y darle formato a las fechas
    @JsonProperty("fecha_vuelta")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate fechaVuelta;

    /*Para mostrarles a las reservas que presenta ese vuelo*/
    @JsonManagedReference("vuelo-reserva")
    @JsonProperty("pasajeros")
    private List<ReservaDTO> reservas;

}
