package com.ejemplomulticapa.service;

import com.ejemplomulticapa.model.Alumno;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class AlumnoService implements IAlumnoService{

    @Override
    public void crearAlumno(Alumno alu) {
        //lógica de creación
        System.out.println("Persona Creada");
    }

    @Override
    public List<Alumno> obtenerAlumnos() {
        //acá debería ir la lógica de devolver la lista de alumnos
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    //métodos de lógica de negocio
    
    
}
