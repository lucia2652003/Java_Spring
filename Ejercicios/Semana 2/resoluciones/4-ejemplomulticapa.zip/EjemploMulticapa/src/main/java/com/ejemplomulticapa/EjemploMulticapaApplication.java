package com.ejemplomulticapa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploMulticapaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploMulticapaApplication.class, args);
	}

}
