
package com.ejemplomulticapa.repository;

import org.springframework.stereotype.Repository;

@Repository
public class AlumnoRepository {
    
    //métodos para llamar a la base de datos, etc
    
}
