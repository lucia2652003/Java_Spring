package com.ejemplomulticapa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploMulticapaApplicationTests {

	@Test
	void contextLoads() {
	}

}
