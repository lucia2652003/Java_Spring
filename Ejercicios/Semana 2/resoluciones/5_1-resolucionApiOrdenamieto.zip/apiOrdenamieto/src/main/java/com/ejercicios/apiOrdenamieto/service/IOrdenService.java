package com.ejercicios.apiOrdenamieto.service;

import java.util.List;


public interface IOrdenService {
     List<String> ordenarNombres(List<String> listaNombres);
}
