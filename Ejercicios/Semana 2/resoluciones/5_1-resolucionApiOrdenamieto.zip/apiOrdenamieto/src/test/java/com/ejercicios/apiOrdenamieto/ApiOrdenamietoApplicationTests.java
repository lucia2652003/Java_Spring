package com.ejercicios.apiOrdenamieto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiOrdenamietoApplicationTests {

	@Test
	void contextLoads() {
	}

}
