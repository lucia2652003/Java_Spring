package com.hackaboss.numerosRomanos;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RomanConverterController {

    @GetMapping("/convertir/{numeroDecimal}")
    public String convertirANumeroRomano(@PathVariable int numeroDecimal) {
        if (numeroDecimal < 1 || numeroDecimal > 1000) {
            return "El número debe estar en el rango de 1 a 1000";
        }

        String numeroRomano = convertirNumeroRomano(numeroDecimal);
        return "El número romano equivalente es: " + numeroRomano;
    }

    // Método para convertir números decimales a números romanos
    private String convertirNumeroRomano(int numero) {
        int[] valoresDecimales = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
        String[] valoresRomanos = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };

        StringBuilder resultado = new StringBuilder();
        int indice = 0;
        while (numero > 0) {
            if (numero >= valoresDecimales[indice]) {
                resultado.append(valoresRomanos[indice]);
                numero -= valoresDecimales[indice];
            } else {
                indice++;
            }
        }
        return resultado.toString();
    }
}
