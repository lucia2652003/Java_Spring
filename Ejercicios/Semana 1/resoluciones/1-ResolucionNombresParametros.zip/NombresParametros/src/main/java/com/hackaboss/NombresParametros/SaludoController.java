package com.hackaboss.NombresParametros;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoController {

    @GetMapping("/saludar")
    public String saludarConNombre(@RequestParam String nombre) {
        return "Hola Mundo " + nombre;
    }

    @GetMapping("/saludarConEdad")
    public String saludarConNombreYEdad(@RequestParam String nombre, @RequestParam int edad) {
        return "Hola Mundo " + nombre + " tienes " + edad + " años";
    }

    @GetMapping("/saludarConProfesion")
    public String saludarConNombreEdadYProfesion(@RequestParam String nombre, @RequestParam int edad, @RequestParam String profesion) {
        return "Hola Mundo " + nombre + " tienes " + edad + " años y eres " + profesion;
    }
}
